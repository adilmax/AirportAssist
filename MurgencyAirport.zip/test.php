<?php 


require_once 'class/classMobileUser.php';


$user = new \airportAssMobUser\mobileUser;


$user->addUserFacebook("");
