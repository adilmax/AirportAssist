<?php
    $result = file_get_contents('https://requestb.in/z0ft9gz0');
    echo $result;
?>