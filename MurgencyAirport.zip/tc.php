<?php 

include("html/tc.php");
?>