<? $title = "Logout";
require_once('responder_header.php');?>
<div class="row service_text_bg_color padding-left">
    <div class="container margin_top">
        <fieldset>
            <legend>Logout</legend> 
        </fieldset>
        <div class="row">
            <div class="container">
                <label class="text-center center-block logout_label_bottom">You have been logout successfully.</label>
            </div>
        </div>
    </div>

<?require_once 'responder_footer.php';?>


