<?php $title = "Thank You";
$titleName = "Thank You";
require_once('header.php');
?>

<div class="row">
    <div class="middle_image faq-subpage">
        <div></div>
    </div>
</div> 
<div class="row">
    <div class="container margin_top">
            <!--        <div class="col-lg-2 col-md-2 col-xs-12 nopadding"></div>-->
            <div class="col-lg-12 col-md-12 col-xs-12 registration_right_contant_bgcolor" >
                <div class="text-center">
                    <h3>Thank you for contacting us!</h3>
                </div>
                <div class="text-center margin_top_welcome">
                    <h4>Our Customer Service team will get back to you shortly.</h4> 
                </div>
                <div class="text-center margin_top_welcome">
                   
                    <p> If you don't receive a respond within 24hr please check your spam mail,</p>
                    <p>otherwise please contact us at MUAirportAssist@MUrgency.com</p>
                </div>
                <div class="text-center margin_top_thankyou">
                    <a href="http://<?=$_SERVER['SERVER_NAME'];?>" class="landing-button_index ">CONTINUE</a>
                </div>
            </div>
    </div>
</div>

<?php require_once('footer.php');?>
