<?php $title = "Thank You";
$titleName = "Thank You";
require_once('header.php');
?>
<!-- Google Code for Murgency ppc Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 879194555;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "c8zGCPbpq2gQu-OdowM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/879194555/?label=c8zGCPbpq2gQu-OdowM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<div class="row">
    <div class="middle_image faq-subpage">
        <div></div>
    </div>
</div> 
<div class="row">
    <div class="container margin_top">
            <!--        <div class="col-lg-2 col-md-2 col-xs-12 nopadding"></div>-->
            <div class="col-lg-12 col-md-12 col-xs-12 registration_right_contant_bgcolor" >
                <div class="text-center">
                    <h3>Thank you. You have submitted your details successfully.</h3>
                </div>
                <div class="text-center margin_top_welcome">
                    <h4>Kindly confirm your registration through the e-mail we just sent you on your registered e-mail id.</h4> 
                    <p> (Check spam folder in case you haven’t received it)</p>
                </div>
                <div class="text-center margin_top_thankyou">
                    <a href="http://<?=$_SERVER['SERVER_NAME'];?>" class="landing-button_index ">CONTINUE</a>
                </div>
            </div>
    </div>
</div>

<?php require_once('footer.php');?>
