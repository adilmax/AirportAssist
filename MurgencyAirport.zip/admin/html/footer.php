<footer style="padding:50px 0px 0px 0px;">
    
    <div class="row" style="margin:25px 0px 20px 0px;">
        <div class="container"> 
            <div class="row">
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                    <a href="http://murgency.com" target="_blank"><img src="image/MU-logo-tag-line-right.png" class="img-responsive center-block"  alt="Airport Assistance" title="MUrgency_logo"/></a>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
           </div>
            
            <div class="row">
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                    <div class="text-center xs_footer" style="font-size: 10px;">MUAirportAssist@MUrgency.com</div>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
            </div>
            <div class="row">
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10">
                    <div class="text-center xs_footer" style="color: #c8c7cf;font-size: 10px;">© Copyright <?=date("Y");?> MUrgency Inc.</div>
                 </div>
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
            </div>
        </div> 
    </div>    
</footer>
    </body>  
</html>
<script src="js/jquery-1.11.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/jquery-ui.js"></script>
<script src="js/validation.js"></script>
<script type="text/javascript" src="js/jquery.timepicker.min.js"></script>
<script src="js/bootstrap-formhelpers.min.js"></script>
 